const express = require("express")
const cors = require("cors")
const mysql = require("mysql2/promise")
const nodemailer = require("nodemailer")
require("dotenv").config()

const app = express()
app.use(cors())
app.use(express.json())

// MySQL Connection Pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: "placement_system",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

// Email Configuration
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
})

// ============= STUDENT ROUTES =============

// Student Login
app.post("/api/student/login", async (req, res) => {
  const { email, password } = req.body
  try {
    const connection = await pool.getConnection()
    const [rows] = await connection.query("SELECT * FROM students WHERE email = ? AND password = ?", [email, password])
    connection.release()

    if (rows.length > 0) {
      res.json({ success: true, user: rows[0] })
    } else {
      res.json({ success: false, message: "Invalid credentials" })
    }
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Student Registration
app.post("/api/student/register", async (req, res) => {
  const { name, email, password, rollNumber, branch, cgpa } = req.body
  try {
    const connection = await pool.getConnection()
    await connection.query(
      "INSERT INTO students (name, email, password, roll_number, branch, cgpa) VALUES (?, ?, ?, ?, ?, ?)",
      [name, email, password, rollNumber, branch, cgpa],
    )
    connection.release()

    await transporter.sendMail({
      to: email,
      subject: "Welcome to PIET Placement Portal",
      html: `<h2>Welcome ${name}!</h2><p>Your account has been created successfully.</p>`,
    })

    res.json({ success: true, message: "Registration successful" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Student Profile
app.get("/api/student/:id", async (req, res) => {
  const { id } = req.params
  try {
    const connection = await pool.getConnection()
    const [rows] = await connection.query("SELECT * FROM students WHERE id = ?", [id])
    connection.release()
    res.json(rows[0] || {})
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// ============= JOB ROUTES =============

// Get All Jobs
app.get("/api/jobs", async (req, res) => {
  try {
    const connection = await pool.getConnection()
    const [jobs] = await connection.query(
      "SELECT j.*, c.name as company_name FROM jobs j JOIN companies c ON j.company_id = c.id",
    )
    connection.release()
    res.json(jobs)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Job Details
app.get("/api/jobs/:id", async (req, res) => {
  const { id } = req.params
  try {
    const connection = await pool.getConnection()
    const [rows] = await connection.query("SELECT * FROM jobs WHERE id = ?", [id])
    connection.release()
    res.json(rows[0] || {})
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Post New Job (Company)
app.post("/api/jobs", async (req, res) => {
  const { companyId, title, description, salaryRange, requiredCgpa, eligibility } = req.body
  try {
    const connection = await pool.getConnection()
    await connection.query(
      "INSERT INTO jobs (company_id, title, description, salary_range, required_cgpa, eligibility) VALUES (?, ?, ?, ?, ?, ?)",
      [companyId, title, description, salaryRange, requiredCgpa, eligibility],
    )
    connection.release()
    res.json({ success: true, message: "Job posted successfully" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// ============= APPLICATION ROUTES =============

// Apply for Job
app.post("/api/applications", async (req, res) => {
  const { studentId, jobId, companyId } = req.body
  try {
    const connection = await pool.getConnection()

    // Check if already applied
    const [existing] = await connection.query("SELECT * FROM applications WHERE student_id = ? AND job_id = ?", [
      studentId,
      jobId,
    ])

    if (existing.length > 0) {
      connection.release()
      return res.json({ success: false, message: "Already applied to this job" })
    }

    await connection.query(
      "INSERT INTO applications (student_id, job_id, company_id, status, applied_on) VALUES (?, ?, ?, ?, NOW())",
      [studentId, jobId, companyId, "pending"],
    )

    // Get student email for notification
    const [student] = await connection.query("SELECT email, name FROM students WHERE id = ?", [studentId])

    const [job] = await connection.query("SELECT title FROM jobs WHERE id = ?", [jobId])

    connection.release()

    if (student.length > 0) {
      await transporter.sendMail({
        to: student[0].email,
        subject: "Application Received - PIET Placement",
        html: `<h2>Application Confirmation</h2><p>Hi ${student[0].name},</p><p>Your application for ${job[0].title} has been received successfully!</p>`,
      })
    }

    res.json({ success: true, message: "Application submitted" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Student Applications
app.get("/api/student/:id/applications", async (req, res) => {
  const { id } = req.params
  try {
    const connection = await pool.getConnection()
    const [applications] = await connection.query(
      "SELECT a.*, j.title, c.name FROM applications a JOIN jobs j ON a.job_id = j.id JOIN companies c ON a.company_id = c.id WHERE a.student_id = ?",
      [id],
    )
    connection.release()
    res.json(applications)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Update Application Status (Admin/Company)
app.put("/api/applications/:id", async (req, res) => {
  const { id } = req.params
  const { status } = req.body
  try {
    const connection = await pool.getConnection()
    await connection.query("UPDATE applications SET status = ? WHERE id = ?", [status, id])
    connection.release()
    res.json({ success: true, message: "Status updated" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// ============= TEST ROUTES =============

// Get Available Tests
app.get("/api/tests", async (req, res) => {
  try {
    const connection = await pool.getConnection()
    const [tests] = await connection.query("SELECT * FROM tests")
    connection.release()
    res.json(tests)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Submit Test Result
app.post("/api/tests/submit", async (req, res) => {
  const { studentId, testId, score, totalQuestions } = req.body
  try {
    const connection = await pool.getConnection()
    await connection.query(
      "INSERT INTO test_results (student_id, test_id, score, total_questions, submitted_on) VALUES (?, ?, ?, ?, NOW())",
      [studentId, testId, score, totalQuestions],
    )

    const [student] = await connection.query("SELECT email FROM students WHERE id = ?", [studentId])

    connection.release()

    if (student.length > 0) {
      await transporter.sendMail({
        to: student[0].email,
        subject: "Test Result - PIET Placement",
        html: `<h2>Test Completed</h2><p>Your score: ${score}/${totalQuestions}</p>`,
      })
    }

    res.json({ success: true, message: "Test submitted" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Test Results
app.get("/api/student/:id/test-results", async (req, res) => {
  const { id } = req.params
  try {
    const connection = await pool.getConnection()
    const [results] = await connection.query(
      "SELECT tr.*, t.name FROM test_results tr JOIN tests t ON tr.test_id = t.id WHERE tr.student_id = ?",
      [id],
    )
    connection.release()
    res.json(results)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// ============= INTERVIEW ROUTES =============

// Schedule Interview
app.post("/api/interviews", async (req, res) => {
  const { applicationId, interviewDate, interviewMode, interviewer } = req.body
  try {
    const connection = await pool.getConnection()
    await connection.query(
      "INSERT INTO interviews (application_id, interview_date, interview_mode, interviewer, status) VALUES (?, ?, ?, ?, ?)",
      [applicationId, interviewDate, interviewMode, interviewer, "scheduled"],
    )
    connection.release()
    res.json({ success: true, message: "Interview scheduled" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Interviews for Student
app.get("/api/student/:id/interviews", async (req, res) => {
  const { id } = req.params
  try {
    const connection = await pool.getConnection()
    const [interviews] = await connection.query(
      "SELECT i.*, j.title, c.name FROM interviews i JOIN applications a ON i.application_id = a.id JOIN jobs j ON a.job_id = j.id JOIN companies c ON a.company_id = c.id WHERE a.student_id = ?",
      [id],
    )
    connection.release()
    res.json(interviews)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// ============= ADMIN ROUTES =============

// Get All Students
app.get("/api/admin/students", async (req, res) => {
  try {
    const connection = await pool.getConnection()
    const [students] = await connection.query("SELECT * FROM students")
    connection.release()
    res.json(students)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Placement Statistics
app.get("/api/admin/statistics", async (req, res) => {
  try {
    const connection = await pool.getConnection()

    const [totalStudents] = await connection.query("SELECT COUNT(*) as count FROM students")
    const [totalCompanies] = await connection.query("SELECT COUNT(*) as count FROM companies")
    const [placedStudents] = await connection.query(
      "SELECT COUNT(DISTINCT student_id) as count FROM applications WHERE status = 'selected'",
    )
    const [avgPackage] = await connection.query("SELECT AVG(CAST(salary_range AS DECIMAL(5,2))) as average FROM jobs")

    connection.release()

    res.json({
      totalStudents: totalStudents[0].count,
      totalCompanies: totalCompanies[0].count,
      placedStudents: placedStudents[0].count,
      averagePackage: avgPackage[0].average,
    })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// ============= COMPANY ROUTES =============

// Company Login
app.post("/api/company/login", async (req, res) => {
  const { email, password } = req.body
  try {
    const connection = await pool.getConnection()
    const [rows] = await connection.query("SELECT * FROM companies WHERE email = ? AND password = ?", [email, password])
    connection.release()

    if (rows.length > 0) {
      res.json({ success: true, user: rows[0] })
    } else {
      res.json({ success: false, message: "Invalid credentials" })
    }
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Company Jobs
app.get("/api/company/:id/jobs", async (req, res) => {
  const { id } = req.params
  try {
    const connection = await pool.getConnection()
    const [jobs] = await connection.query("SELECT * FROM jobs WHERE company_id = ?", [id])
    connection.release()
    res.json(jobs)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Applications for Company Job
app.get("/api/company/:id/applications", async (req, res) => {
  const { id } = req.params
  try {
    const connection = await pool.getConnection()
    const [applications] = await connection.query(
      "SELECT a.*, s.name, s.email, j.title FROM applications a JOIN students s ON a.student_id = s.id JOIN jobs j ON a.job_id = j.id WHERE a.company_id = ?",
      [id],
    )
    connection.release()
    res.json(applications)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ error: "Internal server error" })
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
