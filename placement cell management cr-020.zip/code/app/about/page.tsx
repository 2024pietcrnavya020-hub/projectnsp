"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { ChevronDown } from "lucide-react"

export default function AboutPage() {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null)

  return (
    <main className="min-h-screen bg-white">
      <Navbar onLoginClick={() => {}} />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-4">About Poornima PIET Jaipur</h1>
          <p className="text-xl text-blue-100">
            Premier Institute of Engineering & Technology - Excellence in Education & Placement
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-16">
        {/* Institute Overview */}
        <section className="mb-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Institute Overview</h2>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Poornima Institute of Engineering & Technology (PIET) is one of the most renowned educational
                institutions in Jaipur, offering quality education in engineering and technology for over two decades.
                Located in the heart of Jaipur, our campus is a hub of academic excellence and innovation.
              </p>
              <p className="text-gray-700 mb-4 leading-relaxed">
                PIET is committed to nurturing talented individuals into competent professionals through
                industry-aligned curriculum, cutting-edge infrastructure, and experienced faculty. Our placement cell
                has consistently demonstrated outstanding results with 95%+ placement rates across all branches.
              </p>
              <div className="bg-blue-50 border-l-4 border-blue-900 p-4 rounded">
                <p className="text-blue-900 font-semibold">"Excellence in Education, Excellence in Placement"</p>
              </div>
            </div>
            <div>
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-ZuAz9KPLKcgAaPNIy98gi7UNxOz2Wl.jpg"
                alt="PIET Logo"
                className="w-full max-w-sm"
              />
            </div>
          </div>
        </section>

        {/* Key Stats */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Key Statistics</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { label: "Students Enrolled", value: "3000+", icon: "👨‍🎓" },
              { label: "Placement Rate", value: "95%+", icon: "📈" },
              { label: "Partner Companies", value: "200+", icon: "🏢" },
              { label: "Average Package", value: "5.5 LPA", icon: "💰" },
            ].map((stat, idx) => (
              <div
                key={idx}
                className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg border border-blue-200 text-center"
              >
                <div className="text-4xl mb-2">{stat.icon}</div>
                <p className="text-3xl font-bold text-blue-900 mb-2">{stat.value}</p>
                <p className="text-gray-700 text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Academic Branches */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Academic Branches</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "Computer Science & Engineering", students: "480", placement: "98%" },
              { name: "Information Technology", students: "420", placement: "97%" },
              { name: "Mechanical Engineering", students: "360", placement: "93%" },
              { name: "Civil Engineering", students: "300", placement: "90%" },
              { name: "Electrical Engineering", students: "280", placement: "92%" },
              { name: "Electronics & Communication", students: "260", placement: "94%" },
            ].map((branch, idx) => (
              <div key={idx} className="bg-white border border-gray-200 p-6 rounded-lg hover:shadow-lg transition">
                <h3 className="font-bold text-lg text-gray-900 mb-3">{branch.name}</h3>
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Students: {branch.students}</span>
                  <span className="text-green-600 font-semibold">Placement: {branch.placement}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Placement Cell Mission */}
        <section className="mb-16 bg-blue-50 border-l-4 border-blue-900 p-8 rounded-lg">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Placement Cell Mission</h2>
          <p className="text-gray-700 leading-relaxed mb-4">
            The Placement Cell at Poornima PIET is dedicated to facilitating seamless connections between our talented
            students and leading organizations across industries. We work tirelessly to ensure that every student gets
            an opportunity to achieve their career aspirations.
          </p>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-center gap-2">
              <span className="text-blue-900">✓</span> Organize campus recruitment drives from top companies
            </li>
            <li className="flex items-center gap-2">
              <span className="text-blue-900">✓</span> Conduct skill enhancement and aptitude training programs
            </li>
            <li className="flex items-center gap-2">
              <span className="text-blue-900">✓</span> Maintain strong relationships with 200+ recruiting partners
            </li>
            <li className="flex items-center gap-2">
              <span className="text-blue-900">✓</span> Provide career counseling and mentorship services
            </li>
            <li className="flex items-center gap-2">
              <span className="text-blue-900">✓</span> Support internship and apprenticeship opportunities
            </li>
          </ul>
        </section>

        {/* Top Recruiting Companies */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Top Recruiting Companies</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              "Infosys",
              "TCS",
              "Amazon",
              "HCL Technologies",
              "Wipro",
              "Cognizant",
              "Capgemini",
              "Accenture",
              "Google",
              "Microsoft",
              "IBM",
              "Flipkart",
              "Adobe",
              "Oracle",
              "SAP",
              "Deloitte",
            ].map((company, idx) => (
              <div
                key={idx}
                className="bg-gradient-to-r from-blue-900 to-blue-700 text-white p-4 rounded-lg text-center font-semibold hover:shadow-lg transition"
              >
                {company}
              </div>
            ))}
          </div>
        </section>

        {/* Contact Information */}
        <section className="mb-16 bg-gray-50 p-8 rounded-lg">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Contact Placement Cell</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-bold text-lg text-gray-900 mb-2">Address</h3>
              <p className="text-gray-700">
                Poornima Institute of Engineering & Technology
                <br />
                Jaipur, Rajasthan
                <br />
                India - 302020
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-900 mb-2">Email</h3>
              <p className="text-gray-700">
                placement@poornima.org
                <br />
                careers@poornima.org
                <br />
                info@poornima.org
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-900 mb-2">Phone</h3>
              <p className="text-gray-700">
                +91-141-3521000
                <br />
                +91-141-3521001
                <br />
                +91-9999123456
              </p>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section>
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              {
                q: "When does the placement season start?",
                a: "The placement season typically starts in August and continues until March. Companies visit campus throughout this period for recruitment.",
              },
              {
                q: "Are internships available?",
                a: "Yes, we organize internship drives for students in their 2nd and 3rd years. Many students convert their internships into full-time offers.",
              },
              {
                q: "What is the average salary package?",
                a: "The average salary package is 5.5 LPA with highest packages reaching 12+ LPA. Placement success varies by branch and specialization.",
              },
              {
                q: "How can companies register for recruitment?",
                a: "Companies can contact the placement cell at placement@poornima.org or call +91-141-3521000 to schedule recruitment drives.",
              },
              {
                q: "Are there any pre-placement training programs?",
                a: "Yes, we conduct comprehensive training programs including aptitude tests, group discussions, interview preparation, and technical skill development.",
              },
            ].map((faq, idx) => (
              <div
                key={idx}
                className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                  className="w-full p-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition"
                >
                  <span className="font-semibold text-gray-900 text-left">{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-600 transition-transform ${expandedFaq === idx ? "rotate-180" : ""}`}
                  />
                </button>
                {expandedFaq === idx && (
                  <div className="p-4 bg-white text-gray-700 border-t border-gray-200">{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>

      <Footer />
    </main>
  )
}
