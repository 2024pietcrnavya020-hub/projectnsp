"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import Hero from "@/components/hero"
import LoginModal from "@/components/login-modal"
import Features from "@/components/features"
import Footer from "@/components/footer"

export default function Home() {
  const [showLogin, setShowLogin] = useState(false)

  return (
    <main className="min-h-screen">
      <Navbar onLoginClick={() => setShowLogin(true)} />
      <Hero onGetStarted={() => setShowLogin(true)} />
      <Features />
      <Footer />
      {showLogin && <LoginModal onClose={() => setShowLogin(false)} />}
    </main>
  )
}
