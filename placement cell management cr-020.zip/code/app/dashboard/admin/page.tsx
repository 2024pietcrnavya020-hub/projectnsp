"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import AdminSidebar from "@/components/admin-sidebar"
import AdminOverview from "@/components/admin/overview"
import AdminUsers from "@/components/admin/users"
import AdminCompanies from "@/components/admin/companies"
import AdminPlacements from "@/components/admin/placements"
import AdminReports from "@/components/admin/reports"

type AdminTab = "overview" | "users" | "companies" | "placements" | "reports"

export default function AdminDashboard() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<AdminTab>("overview")
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    const loggedIn = localStorage.getItem("isLoggedIn")
    const userType = localStorage.getItem("userType")

    if (!loggedIn || userType !== "admin") {
      router.push("/")
      return
    }

    setIsLoggedIn(true)
  }, [router])

  if (!isLoggedIn) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <AdminSidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <button
              onClick={() => {
                localStorage.clear()
                router.push("/")
              }}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          {activeTab === "overview" && <AdminOverview />}
          {activeTab === "users" && <AdminUsers />}
          {activeTab === "companies" && <AdminCompanies />}
          {activeTab === "placements" && <AdminPlacements />}
          {activeTab === "reports" && <AdminReports />}
        </div>
      </main>
    </div>
  )
}
