"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import CompanySidebar from "@/components/company-sidebar"
import CompanyProfile from "@/components/company/profile"
import JobPostings from "@/components/company/job-postings"
import CompanyApplications from "@/components/company/applications"
import CompanyTests from "@/components/company/tests"

type CompanyTab = "profile" | "postjob" | "applications" | "tests"

export default function CompanyDashboard() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<CompanyTab>("profile")
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    const loggedIn = localStorage.getItem("isLoggedIn")
    const userType = localStorage.getItem("userType")

    if (!loggedIn || userType !== "company") {
      router.push("/")
      return
    }

    setIsLoggedIn(true)
  }, [router])

  if (!isLoggedIn) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <CompanySidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-900">Company Dashboard</h1>
            <button
              onClick={() => {
                localStorage.clear()
                router.push("/")
              }}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          {activeTab === "profile" && <CompanyProfile />}
          {activeTab === "postjob" && <JobPostings />}
          {activeTab === "applications" && <CompanyApplications />}
          {activeTab === "tests" && <CompanyTests />}
        </div>
      </main>
    </div>
  )
}
