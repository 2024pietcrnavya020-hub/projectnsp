"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import StudentSidebar from "@/components/student-sidebar"
import JobListings from "@/components/student/job-listings"
import StudentProfile from "@/components/student/profile"
import StudentTests from "@/components/student/tests"
import StudentApplications from "@/components/student/applications"
import EmailNotificationCenter from "@/components/email-notification-center"

type Tab = "jobs" | "applications" | "tests" | "profile"

export default function StudentDashboard() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<Tab>("jobs")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [studentData, setStudentData] = useState<any>(null)

  useEffect(() => {
    // Check if user is logged in
    const loggedIn = localStorage.getItem("isLoggedIn")
    const userType = localStorage.getItem("userType")

    if (!loggedIn || userType !== "student") {
      router.push("/")
      return
    }

    setIsLoggedIn(true)

    // Load student data from localStorage
    const email = localStorage.getItem("email") || "student@poornima.edu"
    setStudentData({
      id: "12345",
      name: "Rajesh Kumar",
      email: email,
      rollNumber: "PIET/BT/2024/001",
      branch: "Computer Science",
      cgpa: 8.5,
      appliedJobs: 3,
      testsAttempted: 2,
    })
  }, [router])

  if (!isLoggedIn) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <StudentSidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-4 shadow-sm">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Student Dashboard</h1>
              {studentData && (
                <p className="text-gray-600 mt-1">
                  {studentData.name} • {studentData.rollNumber}
                </p>
              )}
            </div>
            <div className="flex items-center gap-4">
              <EmailNotificationCenter />
              <button
                onClick={() => {
                  localStorage.clear()
                  router.push("/")
                }}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          {activeTab === "jobs" && <JobListings />}
          {activeTab === "applications" && <StudentApplications />}
          {activeTab === "tests" && <StudentTests />}
          {activeTab === "profile" && <StudentProfile studentData={studentData} />}
        </div>
      </main>
    </div>
  )
}
