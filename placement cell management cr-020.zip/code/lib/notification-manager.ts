// Enhanced notification manager that works with email service

import { emailService } from "./email-service"

interface NotificationEvent {
  type: "application" | "test" | "placement" | "company" | "admin"
  data: Record<string, any>
  userEmail: string
  userName: string
}

export class NotificationManager {
  private notifications: NotificationEvent[] = []

  // Trigger notification with email
  triggerNotification(event: NotificationEvent): void {
    this.notifications.push(event)

    // Send email based on type
    switch (event.type) {
      case "application":
        emailService.sendEmail(event.userEmail, event.userName, "application", event.data)
        break
      case "test":
        emailService.sendEmail(event.userEmail, event.userName, "test", event.data)
        break
      case "placement":
        emailService.sendEmail(event.userEmail, event.userName, "placement", event.data)
        break
      case "company":
        emailService.sendEmail(event.userEmail, event.userName, "company", event.data)
        break
      case "admin":
        emailService.sendEmail(event.userEmail, event.userName, "admin", event.data)
        break
    }
  }

  // Get all notifications for a user
  getUserNotifications(email: string): NotificationEvent[] {
    return this.notifications.filter((n) => n.userEmail === email)
  }

  // Get all notifications (for admin)
  getAllNotifications(): NotificationEvent[] {
    return this.notifications
  }
}

export const notificationManager = new NotificationManager()
