// Email notification service for placement system
interface EmailNotification {
  id: string
  recipient: string
  recipientName: string
  subject: string
  message: string
  type: "application" | "test" | "placement" | "company" | "admin" | "profile"
  status: "pending" | "sent" | "failed"
  createdAt: Date
  sentAt?: Date
}

interface EmailTemplate {
  subject: string
  body: string
  action?: {
    text: string
    link: string
  }
}

export class EmailService {
  private notifications: EmailNotification[] = []

  // Email templates for different scenarios
  private templates = {
    applicationSubmitted: (studentName: string, jobTitle: string, company: string): EmailTemplate => ({
      subject: `Application Confirmed - ${company}`,
      body: `Dear ${studentName},\n\nYour application for the ${jobTitle} position at ${company} has been successfully submitted.\n\nWe will notify you once the company reviews your profile.\n\nBest regards,\nPlacement Cell`,
      action: { text: "View Application", link: "/dashboard/student?tab=applications" },
    }),

    applicationSelected: (studentName: string, company: string): EmailTemplate => ({
      subject: `Great News! You're Selected for Interview at ${company}`,
      body: `Dear ${studentName},\n\n${company} has selected your profile for the next round of interviews.\n\nPlease log in to your dashboard to view interview details.\n\nCongratulations!`,
      action: { text: "View Interview Details", link: "/dashboard/student?tab=applications" },
    }),

    applicationRejected: (studentName: string, company: string): EmailTemplate => ({
      subject: `Application Status Update - ${company}`,
      body: `Dear ${studentName},\n\nThank you for your application to ${company}. Unfortunately, they have decided to move forward with other candidates.\n\nDon't be discouraged! Continue applying to other opportunities.`,
      action: { text: "View Other Jobs", link: "/dashboard/student?tab=jobs" },
    }),

    testScheduled: (studentName: string, testName: string, date: string, time: string): EmailTemplate => ({
      subject: `Aptitude Test Scheduled - ${testName}`,
      body: `Dear ${studentName},\n\nYour ${testName} has been scheduled for ${date} at ${time}.\n\nPlease ensure you have a stable internet connection and a quiet environment.\n\nDuration: 2 hours`,
      action: { text: "Take Test", link: "/dashboard/student?tab=tests" },
    }),

    testCompleted: (studentName: string, testName: string, score: number, percentage: number): EmailTemplate => ({
      subject: `Test Results - ${testName}`,
      body: `Dear ${studentName},\n\nYour ${testName} has been evaluated.\n\nScore: ${score}/100 (${percentage}%)\n\nView detailed analysis on your dashboard.`,
      action: { text: "View Results", link: "/dashboard/student?tab=tests" },
    }),

    placementOffer: (studentName: string, company: string, packageValue: string): EmailTemplate => ({
      subject: `Placement Offer - ${company}`,
      body: `Dear ${studentName},\n\nCongratulations! ${company} is pleased to offer you a position.\n\nPackage: ${packageValue} LPA\n\nPlease accept or reject the offer on your dashboard.`,
      action: { text: "View Offer", link: "/dashboard/student?tab=profile" },
    }),

    jobPosted: (company: string, jobTitle: string, applicants: number): EmailTemplate => ({
      subject: `Job Posting Confirmed - ${jobTitle}`,
      body: `Dear ${company},\n\nYour job posting for ${jobTitle} has been successfully published.\n\nCurrent applicants: ${applicants}\n\nManage applications from your dashboard.`,
      action: { text: "View Applications", link: "/dashboard/company?tab=applications" },
    }),

    newApplicant: (company: string, studentName: string, jobTitle: string): EmailTemplate => ({
      subject: `New Application Received - ${jobTitle}`,
      body: `Dear ${company},\n\n${studentName} has applied for the ${jobTitle} position.\n\nReview their profile and take action.`,
      action: { text: "Review Profile", link: "/dashboard/company?tab=applications" },
    }),

    adminAlert: (eventType: string, details: string): EmailTemplate => ({
      subject: `[Admin Alert] ${eventType}`,
      body: `Admin Alert:\n\n${details}\n\nPlease review this in the admin dashboard.`,
      action: { text: "Go to Dashboard", link: "/dashboard/admin" },
    }),
  }

  // Send email notification
  sendEmail(
    recipient: string,
    recipientName: string,
    type: EmailNotification["type"],
    data: Record<string, any>,
  ): EmailNotification {
    let template: EmailTemplate | null = null

    // Select template based on type
    switch (type) {
      case "application":
        if (data.status === "submitted") {
          template = this.templates.applicationSubmitted(recipientName, data.jobTitle, data.company)
        } else if (data.status === "selected") {
          template = this.templates.applicationSelected(recipientName, data.company)
        } else if (data.status === "rejected") {
          template = this.templates.applicationRejected(recipientName, data.company)
        }
        break
      case "test":
        if (data.status === "scheduled") {
          template = this.templates.testScheduled(recipientName, data.testName, data.date, data.time)
        } else if (data.status === "completed") {
          template = this.templates.testCompleted(recipientName, data.testName, data.score, data.percentage)
        }
        break
      case "placement":
        template = this.templates.placementOffer(recipientName, data.company, data.packageValue)
        break
      case "company":
        if (data.eventType === "jobPosted") {
          template = this.templates.jobPosted(recipientName, data.jobTitle, data.applicants)
        } else if (data.eventType === "newApplicant") {
          template = this.templates.newApplicant(recipientName, data.studentName, data.jobTitle)
        }
        break
      case "admin":
        template = this.templates.adminAlert(data.eventType, data.details)
        break
    }

    if (!template) {
      template = { subject: "Notification", body: "You have a new notification" }
    }

    const notification: EmailNotification = {
      id: Math.random().toString(36).substr(2, 9),
      recipient,
      recipientName,
      subject: template.subject,
      message: template.body,
      type,
      status: "sent",
      createdAt: new Date(),
      sentAt: new Date(),
    }

    this.notifications.push(notification)
    console.log("[v0] Email sent to:", recipient, "Subject:", template.subject)
    return notification
  }

  // Get notifications for user
  getNotifications(email: string): EmailNotification[] {
    return this.notifications.filter((n) => n.recipient === email)
  }

  // Get all notifications (admin)
  getAllNotifications(): EmailNotification[] {
    return this.notifications
  }

  // Clear notification
  clearNotification(id: string): void {
    this.notifications = this.notifications.filter((n) => n.id !== id)
  }

  // Mark as read (in real app would update database)
  markAsRead(id: string): void {
    const notification = this.notifications.find((n) => n.id === id)
    if (notification) {
      notification.status = "sent"
    }
  }
}

export const emailService = new EmailService()
