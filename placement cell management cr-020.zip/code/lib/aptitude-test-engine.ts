// Advanced Aptitude Test Engine with real questions and scoring

export interface Question {
  id: string
  category: "quantitative" | "logical" | "verbal" | "technical"
  difficulty: "easy" | "medium" | "hard"
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  timeLimit: number // in seconds
}

export interface TestSession {
  id: string
  testId: string
  studentId: string
  startTime: number
  endTime?: number
  answers: Record<string, number>
  status: "not_started" | "in_progress" | "completed"
  score?: number
}

export interface TestResult {
  sessionId: string
  score: number
  totalQuestions: number
  correctAnswers: number
  accuracy: number
  percentile: number
  categoryScores: Record<string, number>
  timeSpent: number
  timestamp: number
}

// Comprehensive question bank
export const questionBank: Question[] = [
  // Quantitative Questions
  {
    id: "q1",
    category: "quantitative",
    difficulty: "easy",
    question: "If a train travels 120 km in 2 hours, what is its average speed?",
    options: ["50 km/h", "60 km/h", "70 km/h", "80 km/h"],
    correctAnswer: 1,
    explanation: "Average speed = Total distance / Total time = 120 km / 2 hours = 60 km/h",
    timeLimit: 60,
  },
  {
    id: "q2",
    category: "quantitative",
    difficulty: "easy",
    question: "What is 25% of 200?",
    options: ["25", "50", "75", "100"],
    correctAnswer: 1,
    explanation: "25% of 200 = (25/100) × 200 = 50",
    timeLimit: 30,
  },
  {
    id: "q3",
    category: "quantitative",
    difficulty: "medium",
    question:
      "If 5 workers can complete a project in 10 days, how many days will it take for 10 workers to complete the same project?",
    options: ["2 days", "5 days", "10 days", "20 days"],
    correctAnswer: 1,
    explanation: "Work is inversely proportional to workers. (5 × 10) / 10 = 5 days",
    timeLimit: 90,
  },
  {
    id: "q4",
    category: "quantitative",
    difficulty: "medium",
    question: "The average of five numbers is 20. If one number is 40, what is the average of the other four?",
    options: ["15", "17.5", "18", "19"],
    correctAnswer: 1,
    explanation: "Sum of 5 numbers = 20 × 5 = 100. Sum of other 4 = 100 - 40 = 60. Average = 60/4 = 15",
    timeLimit: 90,
  },
  {
    id: "q5",
    category: "quantitative",
    difficulty: "hard",
    question:
      "A shopkeeper gives 10% discount and still makes 20% profit. If the marked price is Rs. 500, what is the cost price?",
    options: ["Rs. 330", "Rs. 360", "Rs. 370", "Rs. 400"],
    correctAnswer: 2,
    explanation: "Selling Price = 500 × 0.9 = 450. If profit is 20%, CP = 450/1.2 = 375 ≈ Rs. 370",
    timeLimit: 120,
  },

  // Logical Reasoning Questions
  {
    id: "q6",
    category: "logical",
    difficulty: "easy",
    question: "If all cats are animals and Fluffy is a cat, then Fluffy is an?",
    options: ["Dog", "Animal", "Bird", "Fish"],
    correctAnswer: 1,
    explanation:
      "This is a simple deductive logic. All cats are animals, Fluffy is a cat, therefore Fluffy is an animal.",
    timeLimit: 60,
  },
  {
    id: "q7",
    category: "logical",
    difficulty: "easy",
    question: "Complete the series: 2, 4, 6, 8, ?",
    options: ["9", "10", "11", "12"],
    correctAnswer: 1,
    explanation: "This is a simple arithmetic sequence with a common difference of 2. The next number is 10.",
    timeLimit: 45,
  },
  {
    id: "q8",
    category: "logical",
    difficulty: "medium",
    question: "If APPLE is coded as 1, 16, 16, 12, 5, then BALL is coded as?",
    options: ["2, 1, 12, 12", "2, 1, 11, 11", "2, 1, 12, 11", "2, 2, 12, 12"],
    correctAnswer: 0,
    explanation: "Each letter is replaced by its position in alphabet. B=2, A=1, L=12, L=12",
    timeLimit: 90,
  },
  {
    id: "q9",
    category: "logical",
    difficulty: "medium",
    question: "Complete the series: 1, 1, 2, 3, 5, 8, 13, ?",
    options: ["18", "20", "21", "24"],
    correctAnswer: 2,
    explanation: "This is the Fibonacci sequence where each number is the sum of the two preceding ones. 8 + 13 = 21",
    timeLimit: 90,
  },
  {
    id: "q10",
    category: "logical",
    difficulty: "hard",
    question: "A watch shows 3:30. If the hour hand and minute hand switch places, what time would it show?",
    options: ["6:15", "7:50", "6:35", "7:15"],
    correctAnswer: 0,
    explanation: "At 3:30, minute hand is at 6, hour hand is between 3 and 4. After switching, it would show 6:15.",
    timeLimit: 120,
  },

  // Verbal Ability Questions
  {
    id: "q11",
    category: "verbal",
    difficulty: "easy",
    question: "Choose the word that is most similar in meaning to 'FASTIDIOUS':",
    options: ["Lazy", "Particular", "Careless", "Generous"],
    correctAnswer: 1,
    explanation: "Fastidious means very concerned with details and quality. Particular has a similar meaning.",
    timeLimit: 60,
  },
  {
    id: "q12",
    category: "verbal",
    difficulty: "easy",
    question: "Select the word that is opposite in meaning to 'PRUDENT':",
    options: ["Wise", "Rash", "Careful", "Thoughtful"],
    correctAnswer: 1,
    explanation: "Prudent means careful and sensible. Rash means hasty and reckless, opposite in meaning.",
    timeLimit: 60,
  },
  {
    id: "q13",
    category: "verbal",
    difficulty: "medium",
    question: "Choose the correct sentence:",
    options: [
      "She neither finished her work nor submitted it.",
      "She not finished her work neither submitted it.",
      "She neither finished nor not submitted her work.",
      "She finished not work nor submitted it.",
    ],
    correctAnswer: 0,
    explanation:
      "The correct structure is 'neither...nor' used for negative statements. Option A is grammatically correct.",
    timeLimit: 90,
  },
  {
    id: "q14",
    category: "verbal",
    difficulty: "medium",
    question: "Read the passage and answer: 'Innovation is the lifeblood of progress.' What does this mean?",
    options: [
      "Innovation can be done safely",
      "Innovation is essential for development",
      "Innovation is dangerous",
      "Progress requires no effort",
    ],
    correctAnswer: 1,
    explanation: "'Lifeblood' means something vital and necessary. So innovation is essential for progress.",
    timeLimit: 90,
  },
  {
    id: "q15",
    category: "verbal",
    difficulty: "hard",
    question: "Choose the word that best completes the analogy: PAINTER : CANVAS :: SCULPTOR : ?",
    options: ["Brush", "Paint", "Stone", "Gallery"],
    correctAnswer: 2,
    explanation: "A painter works on canvas, similarly a sculptor works on stone. Stone is the medium for sculpture.",
    timeLimit: 120,
  },

  // Technical Questions
  {
    id: "q16",
    category: "technical",
    difficulty: "easy",
    question: "What does HTML stand for?",
    options: [
      "Hyper Text Markup Language",
      "High Tech Modern Language",
      "Home Tool Markup Language",
      "Hyperlinks and Text Markup Language",
    ],
    correctAnswer: 0,
    explanation: "HTML stands for HyperText Markup Language, used for creating web pages.",
    timeLimit: 45,
  },
  {
    id: "q17",
    category: "technical",
    difficulty: "easy",
    question: "Which data structure uses LIFO (Last In First Out)?",
    options: ["Queue", "Stack", "Array", "Linked List"],
    correctAnswer: 1,
    explanation: "Stack uses LIFO principle where the last element added is the first one to be removed.",
    timeLimit: 60,
  },
  {
    id: "q18",
    category: "technical",
    difficulty: "medium",
    question: "What is the time complexity of binary search?",
    options: ["O(n)", "O(n²)", "O(log n)", "O(1)"],
    correctAnswer: 2,
    explanation: "Binary search has O(log n) time complexity as it divides the search space in half each time.",
    timeLimit: 90,
  },
  {
    id: "q19",
    category: "technical",
    difficulty: "medium",
    question: "Which of the following is not a RDBMS?",
    options: ["MySQL", "PostgreSQL", "MongoDB", "Oracle"],
    correctAnswer: 2,
    explanation: "MongoDB is a NoSQL database, not a Relational Database Management System (RDBMS).",
    timeLimit: 90,
  },
  {
    id: "q20",
    category: "technical",
    difficulty: "hard",
    question: "What is the difference between var and let in JavaScript?",
    options: [
      "No difference",
      "var is function-scoped, let is block-scoped",
      "let is global-scoped",
      "var cannot be redeclared",
    ],
    correctAnswer: 1,
    explanation: "var is function-scoped while let is block-scoped (more restrictive and safer to use).",
    timeLimit: 120,
  },
]

// Calculate percentile based on score
export function calculatePercentile(score: number, allScores: number[]): number {
  const scoresBelow = allScores.filter((s) => s < score).length
  return Math.round((scoresBelow / allScores.length) * 100)
}

// Calculate category-wise scores
export function calculateCategoryScores(answers: Record<string, number>): Record<string, number> {
  const categoryScores: Record<string, number> = {
    quantitative: 0,
    logical: 0,
    verbal: 0,
    technical: 0,
  }

  const categoryCounts: Record<string, number> = {
    quantitative: 0,
    logical: 0,
    verbal: 0,
    technical: 0,
  }

  questionBank.forEach((q) => {
    if (answers[q.id] === q.correctAnswer) {
      categoryScores[q.category]++
    }
    categoryCounts[q.category]++
  })

  // Convert to percentages
  Object.keys(categoryScores).forEach((key) => {
    categoryScores[key] = Math.round((categoryScores[key] / categoryCounts[key]) * 100)
  })

  return categoryScores
}

// Generate test result
export function generateTestResult(session: TestSession, allResults: TestResult[] = []): TestResult {
  let correctAnswers = 0

  questionBank.forEach((q) => {
    if (session.answers[q.id] === q.correctAnswer) {
      correctAnswers++
    }
  })

  const score = Math.round((correctAnswers / questionBank.length) * 100)
  const timeSpent = (session.endTime || Date.now()) - session.startTime

  // Mock percentile calculation
  const allScores = allResults.map((r) => r.score)
  allScores.push(score)
  const percentile = calculatePercentile(score, allScores)

  return {
    sessionId: session.id,
    score,
    totalQuestions: questionBank.length,
    correctAnswers,
    accuracy: Math.round((correctAnswers / questionBank.length) * 100),
    percentile,
    categoryScores: calculateCategoryScores(session.answers),
    timeSpent,
    timestamp: Date.now(),
  }
}
