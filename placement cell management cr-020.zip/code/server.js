// Backend Server using Node.js & Express
// Install: npm install express cors mysql2 nodemailer dotenv

const express = require("express")
const cors = require("cors")
const mysql = require("mysql2/promise")
const nodemailer = require("nodemailer")
require("dotenv").config()

const app = express()
app.use(cors())
app.use(express.json())

// MySQL Connection Pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: "placement_system",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

// Email Configuration
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
})

// Routes

// Student Login
app.post("/api/student/login", async (req, res) => {
  const { email, password } = req.body
  try {
    const connection = await pool.getConnection()
    const [rows] = await connection.query("SELECT * FROM students WHERE email = ? AND password = ?", [email, password])
    connection.release()

    if (rows.length > 0) {
      res.json({ success: true, user: rows[0] })
    } else {
      res.json({ success: false, message: "Invalid credentials" })
    }
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Available Jobs
app.get("/api/jobs", async (req, res) => {
  try {
    const connection = await pool.getConnection()
    const [jobs] = await connection.query("SELECT * FROM jobs")
    connection.release()
    res.json(jobs)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Apply for Job
app.post("/api/applications", async (req, res) => {
  const { studentId, jobId, companyId } = req.body
  try {
    const connection = await pool.getConnection()
    await connection.query(
      "INSERT INTO applications (student_id, job_id, company_id, status, applied_on) VALUES (?, ?, ?, ?, NOW())",
      [studentId, jobId, companyId, "pending"],
    )

    // Send email notification
    const [student] = await connection.query("SELECT email FROM students WHERE id = ?", [studentId])

    if (student.length > 0) {
      await transporter.sendMail({
        to: student[0].email,
        subject: "Job Application Received",
        html: `<h2>Application Received</h2><p>Your application has been submitted successfully!</p>`,
      })
    }

    connection.release()
    res.json({ success: true, message: "Application submitted" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Get Test Results
app.get("/api/tests/:studentId", async (req, res) => {
  const { studentId } = req.params
  try {
    const connection = await pool.getConnection()
    const [results] = await connection.query("SELECT * FROM test_results WHERE student_id = ?", [studentId])
    connection.release()
    res.json(results)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Submit Test
app.post("/api/tests/submit", async (req, res) => {
  const { studentId, testId, score, totalQuestions } = req.body
  try {
    const connection = await pool.getConnection()
    await connection.query(
      "INSERT INTO test_results (student_id, test_id, score, total_questions, submitted_on) VALUES (?, ?, ?, ?, NOW())",
      [studentId, testId, score, totalQuestions],
    )
    connection.release()
    res.json({ success: true, message: "Test submitted" })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
