"use client"

interface CompanySidebarProps {
  activeTab: string
  setActiveTab: (tab: string) => void
}

export default function CompanySidebar({ activeTab, setActiveTab }: CompanySidebarProps) {
  const menuItems = [
    { id: "profile", label: "Company Profile", icon: "🏢" },
    { id: "postjob", label: "Post Job", icon: "📝" },
    { id: "applications", label: "Applications", icon: "📋" },
    { id: "tests", label: "Manage Tests", icon: "✍️" },
  ]

  return (
    <aside className="w-64 bg-blue-900 text-white shadow-lg">
      {/* Logo */}
      <div className="p-6 flex items-center gap-3 border-b border-blue-800">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-ZuAz9KPLKcgAaPNIy98gi7UNxOz2Wl.jpg"
          alt="Logo"
          className="h-10 w-10 object-contain"
        />
        <div>
          <h2 className="font-bold text-sm">Placement Cell</h2>
          <p className="text-xs text-blue-200">Company Portal</p>
        </div>
      </div>

      {/* Menu */}
      <nav className="p-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full text-left px-4 py-3 rounded-lg mb-2 transition flex items-center gap-3 ${
              activeTab === item.id ? "bg-emerald-600 text-white" : "hover:bg-blue-800"
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
    </aside>
  )
}
