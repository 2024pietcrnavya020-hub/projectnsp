"use client"

import { useState, useEffect } from "react"
import { questionBank, generateTestResult, type TestSession, type TestResult } from "@/lib/aptitude-test-engine"
import { Clock, BarChart3 } from "lucide-react"
import { emailService } from "@/lib/email-service"

export default function EnhancedAptitudeTest({ studentId }: { studentId: string }) {
  const [testSession, setTestSession] = useState<TestSession | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [testResult, setTestResult] = useState<TestResult | null>(null)
  const [showResults, setShowResults] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(0)
  const [allResults, setAllResults] = useState<TestResult[]>([])

  useEffect(() => {
    // Load all results from localStorage
    const saved = JSON.parse(localStorage.getItem("testResults") || "[]")
    setAllResults(saved)
  }, [])

  const startTest = () => {
    const session: TestSession = {
      id: Date.now().toString(),
      testId: "aptitude-test-1",
      studentId,
      startTime: Date.now(),
      answers: {},
      status: "in_progress",
    }
    setTestSession(session)
    setCurrentQuestionIndex(0)
    setTimeRemaining(questionBank.length * 120) // 2 minutes per question average
  }

  const submitAnswer = (answerIndex: number) => {
    if (!testSession) return

    const question = questionBank[currentQuestionIndex]
    const updated = {
      ...testSession,
      answers: {
        ...testSession.answers,
        [question.id]: answerIndex,
      },
    }
    setTestSession(updated)
  }

  const nextQuestion = () => {
    if (currentQuestionIndex < questionBank.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    }
  }

  const previousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const completeTest = () => {
    if (!testSession) return

    const session: TestSession = {
      ...testSession,
      endTime: Date.now(),
      status: "completed",
    }

    const result = generateTestResult(session, allResults)
    setTestResult(result)
    setShowResults(true)

    // Save result
    const updated = [...allResults, result]
    setAllResults(updated)
    localStorage.setItem("testResults", JSON.stringify(updated))

    const studentEmail = localStorage.getItem("email") || "student@poornima.edu"
    const studentName = localStorage.getItem("studentName") || "Student"

    emailService.sendEmail(studentEmail, studentName, "test", {
      status: "completed",
      testName: "Full Aptitude Test",
      score: result.score,
      percentage: result.accuracy,
      percentile: result.percentile,
    })

    // Trigger email notification
    if (typeof window !== "undefined") {
      window.dispatchEvent(
        new CustomEvent("testCompleted", {
          detail: {
            studentId,
            score: result.score,
            percentile: result.percentile,
          },
        }),
      )
    }
  }

  // Timer effect
  useEffect(() => {
    if (!testSession || testSession.status !== "in_progress") return

    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 0) {
          completeTest()
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [testSession])

  if (!testSession) {
    return (
      <div className="w-full max-w-2xl mx-auto p-6">
        <div className="bg-gradient-to-br from-blue-900 to-blue-700 text-white rounded-lg p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Aptitude Test</h2>
          <p className="text-blue-100 mb-6">
            Test your skills across Quantitative, Logical Reasoning, Verbal Ability, and Technical domains.
          </p>
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-blue-800 bg-opacity-50 p-4 rounded">
              <p className="text-2xl font-bold">{questionBank.length}</p>
              <p className="text-sm text-blue-100">Questions</p>
            </div>
            <div className="bg-blue-800 bg-opacity-50 p-4 rounded">
              <p className="text-2xl font-bold">{Math.round((questionBank.length * 120) / 60)}</p>
              <p className="text-sm text-blue-100">Minutes</p>
            </div>
          </div>
          <button
            onClick={startTest}
            className="bg-white text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
          >
            Start Test
          </button>
        </div>
      </div>
    )
  }

  if (showResults && testResult) {
    return (
      <div className="w-full max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <div
              className={`inline-block p-4 rounded-full mb-4 ${testResult.score >= 70 ? "bg-green-100" : "bg-amber-100"}`}
            >
              <BarChart3 className={`w-12 h-12 ${testResult.score >= 70 ? "text-green-600" : "text-amber-600"}`} />
            </div>
            <h2 className="text-3xl font-bold mb-2">Test Results</h2>
            <p className="text-gray-600">Your comprehensive performance analysis</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <p className="text-3xl font-bold text-blue-900">{testResult.score}</p>
              <p className="text-sm text-blue-600">Score (/100)</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <p className="text-3xl font-bold text-green-900">{testResult.percentile}</p>
              <p className="text-sm text-green-600">Percentile</p>
            </div>
            <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
              <p className="text-3xl font-bold text-amber-900">{testResult.correctAnswers}</p>
              <p className="text-sm text-amber-600">Correct Answers</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
              <p className="text-3xl font-bold text-purple-900">{Math.round(testResult.timeSpent / 60)}</p>
              <p className="text-sm text-purple-600">Minutes Taken</p>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4">Category-wise Performance</h3>
            <div className="space-y-4">
              {Object.entries(testResult.categoryScores).map(([category, score]) => (
                <div key={category}>
                  <div className="flex justify-between mb-2">
                    <span className="capitalize font-medium text-gray-700">{category}</span>
                    <span className="font-bold text-gray-900">{score}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className={`h-3 rounded-full transition-all ${
                        score >= 70 ? "bg-green-500" : score >= 50 ? "bg-amber-500" : "bg-red-500"
                      }`}
                      style={{ width: `${score}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => {
                setTestSession(null)
                setShowResults(false)
                setTestResult(null)
              }}
              className="flex-1 bg-blue-900 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors"
            >
              Take Another Test
            </button>
            <button
              onClick={() => {
                // Download report functionality
                const report = `
Test Report - ${new Date().toLocaleString()}
Score: ${testResult.score}/100
Percentile: ${testResult.percentile}%
Correct Answers: ${testResult.correctAnswers}/${testResult.totalQuestions}
Time Spent: ${Math.round(testResult.timeSpent / 60)} minutes

Category Scores:
${Object.entries(testResult.categoryScores)
  .map(([cat, score]) => `${cat.charAt(0).toUpperCase() + cat.slice(1)}: ${score}%`)
  .join("\n")}
                `
                const element = document.createElement("a")
                element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(report))
                element.setAttribute("download", "test-report.txt")
                element.style.display = "none"
                document.body.appendChild(element)
                element.click()
                document.body.removeChild(element)
              }}
              className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
            >
              Download Report
            </button>
          </div>
        </div>
      </div>
    )
  }

  const currentQuestion = questionBank[currentQuestionIndex]
  const selectedAnswer = testSession.answers[currentQuestion.id]

  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-blue-900 text-white p-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold">Aptitude Test</h2>
              <p className="text-blue-100">
                Question {currentQuestionIndex + 1} of {questionBank.length}
              </p>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-2 text-lg font-semibold">
                <Clock className="w-5 h-5" />
                {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, "0")}
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-4 bg-blue-800 rounded-full h-2">
            <div
              className="bg-green-500 h-2 rounded-full transition-all"
              style={{
                width: `${((currentQuestionIndex + 1) / questionBank.length) * 100}%`,
              }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="p-8">
          <div className="mb-2">
            <span
              className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                currentQuestion.difficulty === "easy"
                  ? "bg-green-100 text-green-800"
                  : currentQuestion.difficulty === "medium"
                    ? "bg-amber-100 text-amber-800"
                    : "bg-red-100 text-red-800"
              }`}
            >
              {currentQuestion.difficulty.charAt(0).toUpperCase() + currentQuestion.difficulty.slice(1)} -{" "}
              {currentQuestion.category.charAt(0).toUpperCase() + currentQuestion.category.slice(1)}
            </span>
          </div>

          <h3 className="text-xl font-semibold text-gray-900 mb-6">{currentQuestion.question}</h3>

          {/* Options */}
          <div className="space-y-3 mb-8">
            {currentQuestion.options.map((option, index) => (
              <button
                key={index}
                onClick={() => submitAnswer(index)}
                className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                  selectedAnswer === index ? "border-blue-900 bg-blue-50" : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div className="flex items-center">
                  <div
                    className={`w-5 h-5 rounded-full border-2 mr-4 flex items-center justify-center ${
                      selectedAnswer === index ? "border-blue-900 bg-blue-900" : "border-gray-300"
                    }`}
                  >
                    {selectedAnswer === index && <div className="w-2 h-2 bg-white rounded-full" />}
                  </div>
                  <span className="font-medium text-gray-900">{option}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex justify-between gap-4">
            <button
              onClick={previousQuestion}
              disabled={currentQuestionIndex === 0}
              className="px-6 py-2 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>

            <div className="flex gap-2">
              {Array.from({ length: questionBank.length }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentQuestionIndex(i)}
                  className={`w-8 h-8 rounded-full text-xs font-semibold transition-all ${
                    i === currentQuestionIndex
                      ? "bg-blue-900 text-white"
                      : testSession.answers[questionBank[i].id] !== undefined
                        ? "bg-green-500 text-white"
                        : "bg-gray-200 text-gray-700"
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>

            {currentQuestionIndex === questionBank.length - 1 ? (
              <button
                onClick={completeTest}
                className="px-6 py-2 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700"
              >
                Submit Test
              </button>
            ) : (
              <button
                onClick={nextQuestion}
                className="px-6 py-2 bg-blue-900 text-white rounded-lg font-semibold hover:bg-blue-800"
              >
                Next
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
