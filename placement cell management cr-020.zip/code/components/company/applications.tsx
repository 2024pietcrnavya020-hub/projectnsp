"use client"

export default function CompanyApplications() {
  const applications = [
    {
      id: "1",
      studentName: "Rajesh Kumar",
      position: "Software Engineer",
      email: "rajesh@poornima.edu",
      status: "Under Review",
      appliedDate: "2025-11-01",
    },
    {
      id: "2",
      studentName: "Priya Singh",
      position: "Software Engineer",
      email: "priya@poornima.edu",
      status: "Test Scheduled",
      appliedDate: "2025-10-28",
    },
    {
      id: "3",
      studentName: "Amit Patel",
      position: "Senior Developer",
      email: "amit@poornima.edu",
      status: "Interview Scheduled",
      appliedDate: "2025-10-25",
    },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Candidate Applications</h2>

      <div className="space-y-4">
        {applications.map((app) => (
          <div key={app.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-bold text-gray-900">{app.studentName}</h3>
                <p className="text-gray-600">Position: {app.position}</p>
                <p className="text-gray-600">Email: {app.email}</p>
                <p className="text-sm text-gray-500 mt-2">Applied: {app.appliedDate}</p>
              </div>
              <div className="text-right">
                <span
                  className={`px-4 py-2 rounded-full text-sm font-bold ${
                    app.status === "Under Review"
                      ? "bg-blue-100 text-blue-800"
                      : app.status === "Test Scheduled"
                        ? "bg-amber-100 text-amber-800"
                        : "bg-emerald-100 text-emerald-800"
                  }`}
                >
                  {app.status}
                </span>
                <div className="mt-3 space-y-2">
                  <button className="block w-full text-sm text-blue-600 hover:text-blue-800 font-semibold">
                    View Profile
                  </button>
                  <button className="block w-full text-sm text-emerald-600 hover:text-emerald-800 font-semibold">
                    Schedule Test
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
