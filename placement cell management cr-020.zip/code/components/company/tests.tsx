"use client"

import { useState } from "react"

export default function CompanyTests() {
  const [tests] = useState([
    {
      id: "1",
      name: "Aptitude Test Round 1",
      duration: "90 minutes",
      questions: 100,
      candidates: 45,
      status: "Scheduled",
    },
    {
      id: "2",
      name: "Technical Assessment",
      duration: "120 minutes",
      questions: 50,
      candidates: 20,
      status: "Scheduled",
    },
  ])

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Manage Tests</h2>

      <button className="btn-primary mb-6">+ Create New Test</button>

      <div className="space-y-4">
        {tests.map((test) => (
          <div key={test.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-bold text-gray-900">{test.name}</h3>
                <div className="mt-2 space-y-1 text-sm text-gray-600">
                  <p>⏱️ Duration: {test.duration}</p>
                  <p>❓ Questions: {test.questions}</p>
                  <p>👥 Candidates Registered: {test.candidates}</p>
                </div>
              </div>
              <div className="text-right">
                <span className="px-4 py-2 rounded-full text-sm font-bold bg-blue-100 text-blue-800">
                  {test.status}
                </span>
                <div className="mt-3 space-y-2">
                  <button className="block text-sm text-blue-600 hover:text-blue-800 font-semibold">Edit</button>
                  <button className="block text-sm text-emerald-600 hover:text-emerald-800 font-semibold">
                    View Results
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
