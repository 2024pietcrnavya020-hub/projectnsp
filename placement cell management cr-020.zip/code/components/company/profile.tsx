"use client"

import { useState } from "react"

export default function CompanyProfile() {
  const [company] = useState({
    name: "Infosys Limited",
    email: "hr@infosys.com",
    industry: "IT Services",
    founded: 1981,
    employees: "250000+",
    website: "www.infosys.com",
    description: "Infosys is a global leader in next-generation digital services and consulting.",
  })

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Company Profile</h2>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Company Information */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Company Information</h3>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Company Name</p>
              <p className="text-lg font-semibold text-gray-900">{company.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="text-lg font-semibold text-gray-900">{company.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Industry</p>
              <p className="text-lg font-semibold text-gray-900">{company.industry}</p>
            </div>
            <button className="w-full btn-outline border-blue-900 text-blue-900 hover:bg-blue-50">Edit Profile</button>
          </div>
        </div>

        {/* Additional Information */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Additional Details</h3>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Year Founded</p>
              <p className="text-lg font-semibold text-gray-900">{company.founded}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Employees</p>
              <p className="text-lg font-semibold text-gray-900">{company.employees}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Website</p>
              <p className="text-lg font-semibold text-blue-600">{company.website}</p>
            </div>
          </div>
        </div>

        {/* Company Statistics */}
        <div className="bg-white rounded-lg shadow-md p-6 md:col-span-2">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Recruitment Statistics</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-900">5</p>
              <p className="text-sm text-gray-600">Active Job Postings</p>
            </div>
            <div className="text-center p-4 bg-amber-50 rounded-lg">
              <p className="text-2xl font-bold text-amber-600">240</p>
              <p className="text-sm text-gray-600">Total Applications</p>
            </div>
            <div className="text-center p-4 bg-emerald-50 rounded-lg">
              <p className="text-2xl font-bold text-emerald-600">12</p>
              <p className="text-sm text-gray-600">Tests Scheduled</p>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="bg-white rounded-lg shadow-md p-6 md:col-span-2">
          <h3 className="text-xl font-bold text-gray-900 mb-4">About Company</h3>
          <p className="text-gray-700 leading-relaxed">{company.description}</p>
        </div>
      </div>
    </div>
  )
}
