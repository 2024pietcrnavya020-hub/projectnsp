"use client"

import type React from "react"

import { useState } from "react"

export default function JobPostings() {
  const [jobs, setJobs] = useState([
    {
      id: "1",
      title: "Software Engineer",
      salary: "₹12,00,000",
      location: "Pune",
      applicants: 120,
      status: "Active",
    },
    {
      id: "2",
      title: "Senior Developer",
      salary: "₹15,00,000",
      location: "Bangalore",
      applicants: 80,
      status: "Active",
    },
  ])

  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    salary: "",
    location: "",
    description: "",
    requirements: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.title && formData.salary && formData.location) {
      setJobs([
        ...jobs,
        {
          id: (jobs.length + 1).toString(),
          title: formData.title,
          salary: formData.salary,
          location: formData.location,
          applicants: 0,
          status: "Active",
        },
      ])
      setFormData({ title: "", salary: "", location: "", description: "", requirements: "" })
      setShowForm(false)
      alert("Job posted successfully!")
    }
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Job Postings</h2>

      {!showForm ? (
        <button onClick={() => setShowForm(true)} className="btn-primary mb-6">
          + Post New Job
        </button>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Post a New Job</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Job Title</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Software Engineer"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Salary</label>
                <input
                  type="text"
                  value={formData.salary}
                  onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
                  placeholder="e.g., ₹12,00,000"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">Location</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="e.g., Pune"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Job description..."
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
              ></textarea>
            </div>
            <div className="flex gap-4">
              <button type="submit" className="btn-primary">
                Post Job
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="btn-outline border-blue-900 text-blue-900 hover:bg-blue-50"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Job Listings */}
      <div className="space-y-4">
        {jobs.map((job) => (
          <div key={job.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold text-blue-900">{job.title}</h3>
                <p className="text-gray-600 mt-1">📍 {job.location}</p>
                <p className="text-gray-600 mt-1">💰 {job.salary}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-blue-900">{job.applicants}</p>
                <p className="text-sm text-gray-600">Applications</p>
                <span className="inline-block mt-2 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                  {job.status}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
