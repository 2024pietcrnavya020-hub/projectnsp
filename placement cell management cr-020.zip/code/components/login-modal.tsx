"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"

interface LoginModalProps {
  onClose: () => void
}

export default function LoginModal({ onClose }: LoginModalProps) {
  const router = useRouter()
  const [userType, setUserType] = useState("student")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // Store credentials in localStorage for demo
    localStorage.setItem("userType", userType)
    localStorage.setItem("email", email)
    localStorage.setItem("isLoggedIn", "true")

    // Redirect based on user type
    if (userType === "student") {
      router.push("/dashboard/student")
    } else if (userType === "company") {
      router.push("/dashboard/company")
    } else {
      router.push("/dashboard/admin")
    }
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">Login</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-2xl">
            ×
          </button>
        </div>

        <form onSubmit={handleLogin} className="p-6 space-y-4">
          {/* User Type Selection */}
          <div>
            <label className="block text-sm font-semibold mb-3 text-gray-900">Login As</label>
            <div className="space-y-2">
              {["student", "company", "admin"].map((type) => (
                <label key={type} className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="userType"
                    value={type}
                    checked={userType === type}
                    onChange={(e) => setUserType(e.target.value)}
                    className="w-4 h-4"
                  />
                  <span className="capitalize font-medium text-gray-700">{type}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-semibold mb-2 text-gray-900">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-semibold mb-2 text-gray-900">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
              required
            />
          </div>

          {/* Submit Button */}
          <button type="submit" className="w-full btn-primary">
            Login
          </button>
        </form>

        <div className="p-4 bg-blue-50 border-t text-center text-sm text-gray-600">
          <p>Demo Credentials: any email + any password</p>
        </div>
      </div>
    </div>
  )
}
