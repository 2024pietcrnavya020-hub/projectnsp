export default function Features() {
  const features = [
    {
      title: "For Students",
      icon: "👨‍🎓",
      items: ["Browse Job Postings", "Apply to Companies", "Take Aptitude Tests", "Track Placements"],
    },
    {
      title: "For Companies",
      icon: "🏢",
      items: ["Post Job Openings", "Review Applications", "Schedule Tests", "Manage Interviews"],
    },
    {
      title: "For Admin",
      icon: "⚙️",
      items: ["Manage Users", "Oversee Placements", "Generate Reports", "System Configuration"],
    },
  ]

  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-12 text-gray-900">Portal Features</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, idx) => (
            <div key={idx} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-5xl mb-4">{feature.icon}</div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">{feature.title}</h3>
              <ul className="space-y-2">
                {feature.items.map((item, i) => (
                  <li key={i} className="text-gray-700 flex items-center gap-2">
                    <span className="text-emerald-600">✓</span> {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
