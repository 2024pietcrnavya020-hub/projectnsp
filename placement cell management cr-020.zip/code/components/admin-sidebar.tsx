"use client"

interface AdminSidebarProps {
  activeTab: string
  setActiveTab: (tab: string) => void
}

export default function AdminSidebar({ activeTab, setActiveTab }: AdminSidebarProps) {
  const menuItems = [
    { id: "overview", label: "Dashboard Overview", icon: "📊" },
    { id: "users", label: "Manage Users", icon: "👥" },
    { id: "companies", label: "Companies", icon: "🏢" },
    { id: "placements", label: "Placements", icon: "📈" },
    { id: "reports", label: "Reports", icon: "📋" },
  ]

  return (
    <aside className="w-64 bg-blue-900 text-white shadow-lg">
      {/* Logo */}
      <div className="p-6 flex items-center gap-3 border-b border-blue-800">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-ZuAz9KPLKcgAaPNIy98gi7UNxOz2Wl.jpg"
          alt="Logo"
          className="h-10 w-10 object-contain"
        />
        <div>
          <h2 className="font-bold text-sm">Placement Cell</h2>
          <p className="text-xs text-blue-200">Admin Panel</p>
        </div>
      </div>

      {/* Menu */}
      <nav className="p-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full text-left px-4 py-3 rounded-lg mb-2 transition flex items-center gap-3 ${
              activeTab === item.id ? "bg-red-500 text-white" : "hover:bg-blue-800"
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
    </aside>
  )
}
