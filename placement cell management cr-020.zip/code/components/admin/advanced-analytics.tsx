"use client"

import { useState } from "react"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { Users, Briefcase, Target, Award } from "lucide-react"

const placementData = [
  { month: "Jan", placements: 12, offers: 15, students: 250 },
  { month: "Feb", placements: 19, offers: 22, students: 260 },
  { month: "Mar", placements: 15, offers: 18, students: 270 },
  { month: "Apr", placements: 25, offers: 28, students: 280 },
  { month: "May", placements: 22, offers: 25, students: 290 },
  { month: "Jun", placements: 30, offers: 35, students: 300 },
]

const salaryData = [
  { range: "3-5 LPA", count: 15, percentage: 12 },
  { range: "5-7 LPA", count: 35, percentage: 28 },
  { range: "7-10 LPA", count: 45, percentage: 36 },
  { range: "10-15 LPA", count: 22, percentage: 18 },
  { range: "15+ LPA", count: 8, percentage: 6 },
]

const companyData = [
  { name: "Infosys", placements: 35, packages: "5-12 LPA" },
  { name: "TCS", placements: 28, packages: "6-11 LPA" },
  { name: "Amazon", placements: 18, packages: "8-18 LPA" },
  { name: "Wipro", placements: 22, packages: "5-10 LPA" },
  { name: "HCL", placements: 15, packages: "4-9 LPA" },
]

const COLORS = ["#1e3a8a", "#3b82f6", "#60a5fa", "#93c5fd", "#dbeafe"]

export default function AdvancedAnalytics() {
  const [timeRange, setTimeRange] = useState("6months")

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Analytics & Reports</h2>
          <p className="text-gray-600">Comprehensive placement statistics and trends</p>
        </div>
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium"
        >
          <option value="month">Last Month</option>
          <option value="quarter">Last Quarter</option>
          <option value="6months">Last 6 Months</option>
          <option value="year">Last Year</option>
        </select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Total Placements</p>
              <p className="text-3xl font-bold text-gray-900">123</p>
              <p className="text-green-600 text-xs mt-2">↑ 15% from last month</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Briefcase className="w-6 h-6 text-blue-900" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Average Package</p>
              <p className="text-3xl font-bold text-gray-900">7.2 LPA</p>
              <p className="text-green-600 text-xs mt-2">↑ 8% increase</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <Award className="w-6 h-6 text-green-900" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Placement Rate</p>
              <p className="text-3xl font-bold text-gray-900">85%</p>
              <p className="text-green-600 text-xs mt-2">↑ 5% from last year</p>
            </div>
            <div className="bg-amber-100 p-3 rounded-lg">
              <Target className="w-6 h-6 text-amber-900" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Active Companies</p>
              <p className="text-3xl font-bold text-gray-900">24</p>
              <p className="text-green-600 text-xs mt-2">↑ 3 new companies</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-purple-900" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Placement Trend */}
        <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Placement Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={placementData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#fff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="placements"
                stroke="#1e3a8a"
                strokeWidth={2}
                dot={{ fill: "#1e3a8a", r: 4 }}
              />
              <Line type="monotone" dataKey="offers" stroke="#059669" strokeWidth={2} dot={{ fill: "#059669", r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Salary Distribution */}
        <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Salary Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={salaryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => `${entry.range}: ${entry.count}`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="count"
              >
                {salaryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Company Performance */}
        <div className="bg-white rounded-lg shadow p-6 border border-gray-200 lg:col-span-2">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Top Recruiting Companies</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={companyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#fff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="placements" fill="#1e3a8a" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-5 gap-3">
            {companyData.map((company, index) => (
              <div key={company.name} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                <p className="text-sm font-semibold text-gray-900">{company.name}</p>
                <p className="text-xs text-gray-600 mt-1">Placements: {company.placements}</p>
                <p className="text-xs text-green-600 font-semibold">{company.packages}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Branch-wise Placement */}
      <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Branch-wise Placement Rate</h3>
        <div className="space-y-4">
          {[
            { name: "Computer Science", rate: 92, students: 120 },
            { name: "Electronics & Communication", rate: 85, students: 100 },
            { name: "Mechanical Engineering", rate: 78, students: 110 },
            { name: "Civil Engineering", rate: 65, students: 95 },
          ].map((branch) => (
            <div key={branch.name}>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-900">{branch.name}</span>
                <span className="text-sm font-semibold text-gray-900">
                  {branch.rate}% ({Math.round((branch.rate / 100) * branch.students)} students)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="h-3 rounded-full bg-gradient-to-r from-blue-900 to-green-600 transition-all"
                  style={{ width: `${branch.rate}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
