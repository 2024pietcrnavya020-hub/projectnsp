"use client"

export default function AdminCompanies() {
  const companies = [
    { id: "1", name: "Infosys", hrEmail: "hr@infosys.com", jobsPosted: 5, applicants: 120 },
    { id: "2", name: "Amazon", hrEmail: "recruit@amazon.com", jobsPosted: 3, applicants: 95 },
    { id: "3", name: "TCS", hrEmail: "hr@tcs.com", jobsPosted: 4, applicants: 140 },
    { id: "4", name: "HCL Technologies", hrEmail: "hr@hcl.com", jobsPosted: 2, applicants: 60 },
    { id: "5", name: "Wipro", hrEmail: "recruit@wipro.com", jobsPosted: 3, applicants: 85 },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Registered Companies</h2>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="w-full">
          <thead className="bg-blue-900 text-white">
            <tr>
              <th className="text-left py-4 px-6">Company Name</th>
              <th className="text-left py-4 px-6">HR Email</th>
              <th className="text-left py-4 px-6">Jobs Posted</th>
              <th className="text-left py-4 px-6">Total Applicants</th>
              <th className="text-left py-4 px-6">Status</th>
            </tr>
          </thead>
          <tbody>
            {companies.map((company) => (
              <tr key={company.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-6 font-semibold text-gray-900">{company.name}</td>
                <td className="py-4 px-6 text-gray-600">{company.hrEmail}</td>
                <td className="py-4 px-6 font-semibold text-blue-900">{company.jobsPosted}</td>
                <td className="py-4 px-6 font-semibold text-gray-900">{company.applicants}</td>
                <td className="py-4 px-6">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                    Active
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
