"use client"

export default function AdminOverview() {
  const stats = [
    { label: "Total Students", value: 450, icon: "👨‍🎓" },
    { label: "Registered Companies", value: 25, icon: "🏢" },
    { label: "Total Placements", value: 380, icon: "✓" },
    { label: "Placement Rate", value: "84.4%", icon: "📈" },
  ]

  const recentPlacements = [
    { student: "Rajesh Kumar", company: "Infosys", salary: "₹12,00,000", date: "2025-11-01" },
    { student: "Priya Singh", company: "Amazon", salary: "₹16,00,000", date: "2025-11-02" },
    { student: "Amit Patel", company: "TCS", salary: "₹10,00,000", date: "2025-11-03" },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Dashboard Overview</h2>

      {/* Statistics */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 text-sm font-semibold">{stat.label}</p>
                <p className="text-3xl font-bold text-blue-900 mt-2">{stat.value}</p>
              </div>
              <span className="text-4xl">{stat.icon}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Placements */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Recent Placements</h3>
        <table className="w-full">
          <thead className="border-b border-gray-200">
            <tr>
              <th className="text-left py-3 text-gray-700 font-semibold">Student Name</th>
              <th className="text-left py-3 text-gray-700 font-semibold">Company</th>
              <th className="text-left py-3 text-gray-700 font-semibold">Salary</th>
              <th className="text-left py-3 text-gray-700 font-semibold">Date</th>
            </tr>
          </thead>
          <tbody>
            {recentPlacements.map((placement, idx) => (
              <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 text-gray-900">{placement.student}</td>
                <td className="py-3 text-gray-900">{placement.company}</td>
                <td className="py-3 font-semibold text-emerald-600">{placement.salary}</td>
                <td className="py-3 text-gray-600 text-sm">{placement.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
