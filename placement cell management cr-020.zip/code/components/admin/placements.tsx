"use client"

export default function AdminPlacements() {
  const placements = [
    {
      id: "1",
      student: "Rajesh Kumar",
      company: "Infosys",
      position: "Software Engineer",
      salary: "₹12,00,000",
      date: "2025-11-01",
    },
    { id: "2", student: "Priya Singh", company: "Amazon", position: "SDE", salary: "₹16,00,000", date: "2025-11-02" },
    {
      id: "3",
      student: "Amit Patel",
      company: "TCS",
      position: "Associate Engineer",
      salary: "₹10,00,000",
      date: "2025-11-03",
    },
    {
      id: "4",
      student: "Neha Sharma",
      company: "HCL",
      position: "Trainee Engineer",
      salary: "₹11,00,000",
      date: "2025-11-04",
    },
    {
      id: "5",
      student: "Vikram Gupta",
      company: "Wipro",
      position: "Software Engineer",
      salary: "₹11,50,000",
      date: "2025-11-05",
    },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Placements Record</h2>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="w-full">
          <thead className="bg-blue-900 text-white">
            <tr>
              <th className="text-left py-4 px-6">Student</th>
              <th className="text-left py-4 px-6">Company</th>
              <th className="text-left py-4 px-6">Position</th>
              <th className="text-left py-4 px-6">Salary</th>
              <th className="text-left py-4 px-6">Date</th>
            </tr>
          </thead>
          <tbody>
            {placements.map((placement) => (
              <tr key={placement.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-6 font-semibold text-gray-900">{placement.student}</td>
                <td className="py-4 px-6 text-gray-900">{placement.company}</td>
                <td className="py-4 px-6 text-gray-600">{placement.position}</td>
                <td className="py-4 px-6 font-semibold text-emerald-600">{placement.salary}</td>
                <td className="py-4 px-6 text-gray-600 text-sm">{placement.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
