"use client"

import { useState } from "react"

export default function AdminUsers() {
  const [users] = useState([
    { id: "1", name: "Rajesh Kumar", email: "rajesh@poornima.edu", role: "Student", branch: "CSE" },
    { id: "2", name: "Priya Singh", email: "priya@poornima.edu", role: "Student", branch: "IT" },
    { id: "3", name: "Amit Patel", email: "amit@poornima.edu", role: "Student", branch: "CSE" },
    { id: "4", name: "Infosys HR", email: "hr@infosys.com", role: "Company", branch: "N/A" },
    { id: "5", name: "Amazon Recruiter", email: "recruit@amazon.com", role: "Company", branch: "N/A" },
  ])

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Manage Users</h2>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="w-full">
          <thead className="bg-blue-900 text-white">
            <tr>
              <th className="text-left py-4 px-6">Name</th>
              <th className="text-left py-4 px-6">Email</th>
              <th className="text-left py-4 px-6">Role</th>
              <th className="text-left py-4 px-6">Branch/Department</th>
              <th className="text-left py-4 px-6">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-6 font-semibold text-gray-900">{user.name}</td>
                <td className="py-4 px-6 text-gray-600">{user.email}</td>
                <td className="py-4 px-6">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                      user.role === "Student" ? "bg-blue-100 text-blue-800" : "bg-amber-100 text-amber-800"
                    }`}
                  >
                    {user.role}
                  </span>
                </td>
                <td className="py-4 px-6 text-gray-600">{user.branch}</td>
                <td className="py-4 px-6">
                  <button className="text-blue-600 hover:text-blue-800 text-sm font-semibold mr-3">Edit</button>
                  <button className="text-red-600 hover:text-red-800 text-sm font-semibold">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
