"use client"

interface HeroProps {
  onGetStarted: () => void
}

export default function Hero({ onGetStarted }: HeroProps) {
  return (
    <section className="bg-gradient-to-r from-blue-900 to-blue-800 text-white py-20 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-5xl font-bold mb-4">PLACEMENT CELL MANAGEMENT SYSTEM</h2>
        <p className="text-xl mb-8 text-blue-100">Bridging Students, Companies, and Opportunities</p>
        <div className="flex gap-4 justify-center">
          <button
            onClick={onGetStarted}
            className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-3 rounded-lg font-semibold transition"
          >
            Get Started
          </button>
          <button className="border-2 border-white hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition">
            Learn More
          </button>
        </div>
      </div>
    </section>
  )
}
