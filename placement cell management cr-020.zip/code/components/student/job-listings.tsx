"use client"

import { useState } from "react"
import { emailService } from "@/lib/email-service"
import { Mail, MapPin, Briefcase, Calendar } from "lucide-react"

export default function JobListings() {
  const [applications, setApplications] = useState<string[]>([])
  const [showEmailNotification, setShowEmailNotification] = useState(false)

  const jobs = [
    {
      id: "1",
      company: "Infosys",
      position: "Software Engineer",
      salary: "₹12,00,000",
      location: "Pune",
      description: "We are looking for talented engineers to join our team.",
      requirements: ["B.Tech in CS/IT", "Min 7.0 CGPA", "0 years experience"],
      deadline: "2025-12-31",
    },
    {
      id: "2",
      company: "Amazon",
      position: "Software Development Engineer",
      salary: "₹16,00,000",
      location: "Bangalore",
      description: "Work on innovative cloud solutions.",
      requirements: ["B.Tech in CS/IT", "Min 8.0 CGPA", "Strong problem solving"],
      deadline: "2025-12-25",
    },
    {
      id: "3",
      company: "TCS",
      position: "Associate Engineer",
      salary: "₹10,00,000",
      location: "Hyderabad",
      description: "Start your career with India's largest IT company.",
      requirements: ["B.Tech in any branch", "Min 6.0 CGPA", "Communication skills"],
      deadline: "2026-01-15",
    },
    {
      id: "4",
      company: "HCL Technologies",
      position: "Trainee Software Engineer",
      salary: "₹11,00,000",
      location: "Noida",
      description: "Join our fast-growing engineering team.",
      requirements: ["B.Tech in CS/IT", "Min 6.5 CGPA", "Java/Python knowledge"],
      deadline: "2025-12-30",
    },
    {
      id: "5",
      company: "Wipro",
      position: "Software Engineer",
      salary: "₹11,50,000",
      location: "Multiple Cities",
      description: "Be part of digital transformation.",
      requirements: ["B.Tech in any branch", "Min 6.0 CGPA", "Willing to relocate"],
      deadline: "2026-01-10",
    },
  ]

  const handleApply = (job: (typeof jobs)[0]) => {
    if (!applications.includes(job.id)) {
      setApplications([...applications, job.id])

      const studentEmail = localStorage.getItem("email") || "student@poornima.edu"
      const studentName = localStorage.getItem("studentName") || "Student"

      emailService.sendEmail(studentEmail, studentName, "application", {
        status: "submitted",
        jobTitle: job.position,
        company: job.company,
      })

      setShowEmailNotification(true)
      setTimeout(() => setShowEmailNotification(false), 3000)
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Available Job Postings</h2>
        <span className="text-sm text-gray-600">{jobs.length} opportunities available</span>
      </div>

      {/* Email Notification Toast */}
      {showEmailNotification && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
          <Mail className="w-5 h-5 text-green-600" />
          <span className="text-green-800">Application submitted! Email confirmation sent.</span>
        </div>
      )}

      <div className="space-y-4">
        {jobs.map((job) => (
          <div
            key={job.id}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow border border-gray-100"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold text-blue-900 mb-1">{job.company}</h3>
                <p className="text-gray-700 font-semibold flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  {job.position}
                </p>
              </div>
              <span className="bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-semibold">
                {job.salary}
              </span>
            </div>

            <p className="text-gray-600 mb-4">{job.description}</p>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2">Requirements:</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  {job.requirements.map((req, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="text-blue-900">•</span> {req}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2">Details:</p>
                <p className="text-sm text-gray-600 flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {job.location}
                </p>
                <p className="text-sm text-gray-600 flex items-center gap-2 mt-1">
                  <Calendar className="w-4 h-4" />
                  Deadline: {job.deadline}
                </p>
              </div>
            </div>

            <button
              onClick={() => handleApply(job)}
              disabled={applications.includes(job.id)}
              className={`w-full md:w-auto px-6 py-2 rounded-lg font-semibold transition-all ${
                applications.includes(job.id)
                  ? "bg-gray-200 text-gray-600 cursor-not-allowed"
                  : "bg-blue-900 text-white hover:bg-blue-800"
              }`}
            >
              {applications.includes(job.id) ? "✓ Applied" : "Apply Now"}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
