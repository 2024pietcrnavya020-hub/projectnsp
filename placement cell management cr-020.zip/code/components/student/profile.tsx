"use client"

interface StudentProfileProps {
  studentData: any
}

export default function StudentProfile({ studentData }: StudentProfileProps) {
  if (!studentData) {
    return <div>Loading profile...</div>
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">My Profile</h2>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Basic Information */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Basic Information</h3>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Full Name</p>
              <p className="text-lg font-semibold text-gray-900">{studentData.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="text-lg font-semibold text-gray-900">{studentData.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Roll Number</p>
              <p className="text-lg font-semibold text-gray-900">{studentData.rollNumber}</p>
            </div>
            <button className="w-full btn-outline border-blue-900 text-blue-900 hover:bg-blue-50">Edit Profile</button>
          </div>
        </div>

        {/* Academic Information */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Academic Information</h3>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Branch</p>
              <p className="text-lg font-semibold text-gray-900">{studentData.branch}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">CGPA</p>
              <p className="text-lg font-semibold text-emerald-600">{studentData.cgpa}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Year</p>
              <p className="text-lg font-semibold text-gray-900">4th Year (Final)</p>
            </div>
          </div>
        </div>

        {/* Placement Statistics */}
        <div className="bg-white rounded-lg shadow-md p-6 md:col-span-2">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Placement Statistics</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-900">{studentData.appliedJobs}</p>
              <p className="text-sm text-gray-600">Jobs Applied</p>
            </div>
            <div className="text-center p-4 bg-amber-50 rounded-lg">
              <p className="text-2xl font-bold text-amber-600">{studentData.testsAttempted}</p>
              <p className="text-sm text-gray-600">Tests Attempted</p>
            </div>
            <div className="text-center p-4 bg-emerald-50 rounded-lg">
              <p className="text-2xl font-bold text-emerald-600">0</p>
              <p className="text-sm text-gray-600">Offers</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
