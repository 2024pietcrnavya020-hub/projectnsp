"use client"

import { useState } from "react"

export default function StudentTests() {
  const [completedTests, setCompletedTests] = useState(["1", "2"])

  const tests = [
    {
      id: "1",
      title: "Quantitative Aptitude",
      duration: "90 minutes",
      questions: 100,
      status: "Completed",
      score: "78/100",
      company: "Infosys",
    },
    {
      id: "2",
      title: "Logical Reasoning",
      duration: "60 minutes",
      questions: 80,
      status: "Completed",
      score: "65/80",
      company: "TCS",
    },
    {
      id: "3",
      title: "Verbal Ability",
      duration: "75 minutes",
      questions: 85,
      status: "Available",
      score: "-",
      company: "Amazon",
    },
    {
      id: "4",
      title: "Technical Assessment",
      duration: "120 minutes",
      questions: 50,
      status: "Upcoming",
      score: "-",
      company: "Amazon",
    },
  ]

  const handleStartTest = (testId: string) => {
    if (!completedTests.includes(testId)) {
      alert("Starting test: " + testId)
      // In real app, navigate to test page
    }
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Aptitude Tests</h2>

      <div className="grid md:grid-cols-2 gap-6">
        {tests.map((test) => (
          <div key={test.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-lg font-bold text-blue-900">{test.title}</h3>
                <p className="text-sm text-gray-600">{test.company}</p>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-bold ${
                  test.status === "Completed"
                    ? "bg-emerald-100 text-emerald-800"
                    : test.status === "Available"
                      ? "bg-blue-100 text-blue-800"
                      : "bg-gray-100 text-gray-800"
                }`}
              >
                {test.status}
              </span>
            </div>

            <div className="space-y-2 mb-4 text-sm text-gray-600">
              <p>⏱️ Duration: {test.duration}</p>
              <p>❓ Questions: {test.questions}</p>
              {test.status === "Completed" && <p className="font-semibold text-emerald-600">Score: {test.score}</p>}
            </div>

            <button
              onClick={() => handleStartTest(test.id)}
              disabled={test.status === "Completed" || test.status === "Upcoming"}
              className={`w-full ${
                test.status === "Completed"
                  ? "bg-gray-400 cursor-not-allowed"
                  : test.status === "Upcoming"
                    ? "bg-gray-400 cursor-not-allowed"
                    : "btn-primary"
              }`}
            >
              {test.status === "Completed" ? "✓ Completed" : test.status === "Upcoming" ? "Coming Soon" : "Start Test"}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
