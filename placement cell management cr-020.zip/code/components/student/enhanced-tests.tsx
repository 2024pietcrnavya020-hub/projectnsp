"use client"

import { useState } from "react"
import { Clock, AlertCircle, TrendingUp } from "lucide-react"
import EnhancedAptitudeTest from "@/components/enhanced-aptitude-test"

export default function EnhancedTests() {
  const [selectedTest, setSelectedTest] = useState<string | null>(null)
  const [studentId] = useState("STU001")

  const tests = [
    {
      id: "aptitude-1",
      name: "Full Aptitude Test",
      description: "Comprehensive test covering Quantitative, Logical Reasoning, Verbal Ability, and Technical skills",
      duration: "40 minutes",
      questions: 20,
      status: "available",
      attempts: 0,
      bestScore: null,
    },
    {
      id: "quant-1",
      name: "Quantitative Skills",
      description: "Test your mathematical and analytical abilities",
      duration: "15 minutes",
      questions: 5,
      status: "available",
      attempts: 1,
      bestScore: 80,
    },
    {
      id: "logical-1",
      name: "Logical Reasoning",
      description: "Assess your problem-solving and logical thinking capabilities",
      duration: "15 minutes",
      questions: 5,
      status: "available",
      attempts: 2,
      bestScore: 75,
    },
    {
      id: "verbal-1",
      name: "Verbal Ability",
      description: "Evaluate your English language and comprehension skills",
      duration: "15 minutes",
      questions: 5,
      status: "available",
      attempts: 1,
      bestScore: 85,
    },
  ]

  if (selectedTest) {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setSelectedTest(null)}
          className="text-blue-900 hover:text-blue-700 font-semibold flex items-center gap-2"
        >
          ← Back to Tests
        </button>
        <EnhancedAptitudeTest studentId={studentId} />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-2">Aptitude Tests</h2>
        <p>Improve your skills and prepare for placements with our comprehensive test suite</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {tests.map((test) => (
          <div
            key={test.id}
            className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-1">{test.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{test.description}</p>
              </div>
              {test.status === "available" && (
                <span className="inline-block px-3 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">
                  Available
                </span>
              )}
            </div>

            <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {test.duration}
              </div>
              <div className="flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                {test.questions} Questions
              </div>
            </div>

            {test.bestScore !== null && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <span className="text-sm text-green-800">
                    <strong>Best Score:</strong> {test.bestScore}/100 ({test.attempts} attempt
                    {test.attempts !== 1 ? "s" : ""})
                  </span>
                </div>
              </div>
            )}

            <button
              onClick={() => setSelectedTest(test.id)}
              className="w-full bg-blue-900 text-white py-2 rounded-lg font-semibold hover:bg-blue-800 transition-colors"
            >
              Take Test
            </button>
          </div>
        ))}
      </div>

      {/* Performance Summary */}
      <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <h3 className="text-lg font-bold mb-4">Your Performance Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-2xl font-bold text-blue-900">4</p>
            <p className="text-sm text-blue-600">Tests Available</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <p className="text-2xl font-bold text-green-900">4</p>
            <p className="text-sm text-green-600">Tests Attempted</p>
          </div>
          <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
            <p className="text-2xl font-bold text-amber-900">80</p>
            <p className="text-sm text-amber-600">Average Score</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <p className="text-2xl font-bold text-purple-900">75th</p>
            <p className="text-sm text-purple-600">Average Percentile</p>
          </div>
        </div>
      </div>
    </div>
  )
}
