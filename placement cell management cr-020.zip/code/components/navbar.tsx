"use client"
import Link from "next/link"

interface NavbarProps {
  onLoginClick: () => void
}

export default function Navbar({ onLoginClick }: NavbarProps) {
  return (
    <nav className="bg-blue-900 text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo Section */}
        <Link href="/" className="flex items-center gap-3 hover:opacity-90 transition">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-ZuAz9KPLKcgAaPNIy98gi7UNxOz2Wl.jpg"
            alt="Poornima PIET Logo"
            className="h-12 w-12 object-contain"
          />
          <div>
            <h1 className="font-bold text-lg">Placement Cell</h1>
            <p className="text-xs text-blue-100">Poornima PIET Jaipur</p>
          </div>
        </Link>

        {/* Navigation Links */}
        <div className="hidden md:flex gap-6">
          <Link href="/about" className="hover:text-blue-200 transition font-medium">
            About
          </Link>
          <Link href="#companies" className="hover:text-blue-200 transition font-medium">
            Companies
          </Link>
          <Link href="#placements" className="hover:text-blue-200 transition font-medium">
            Placements
          </Link>
          <Link href="#tests" className="hover:text-blue-200 transition font-medium">
            Aptitude Tests
          </Link>
        </div>

        {/* Login Button */}
        <button
          onClick={onLoginClick}
          className="btn-outline text-white border-white hover:bg-blue-800 transition-colors font-medium"
        >
          Login
        </button>
      </div>
    </nav>
  )
}
