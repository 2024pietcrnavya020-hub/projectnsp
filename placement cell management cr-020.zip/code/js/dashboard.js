// Get current user from localStorage
const currentUser = JSON.parse(localStorage.getItem("currentUser"))
if (!currentUser) {
  window.location.href = "index.html"
}

// Update user name in header
document.querySelector(".user-profile span").textContent = "John Doe"

// Tab Switching
function switchTab(tabName) {
  // Hide all tabs
  document.querySelectorAll(".tab-content").forEach((tab) => {
    tab.classList.remove("active")
  })

  // Remove active class from nav items
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
  })

  // Show selected tab
  const selectedTab = document.getElementById(tabName)
  if (selectedTab) {
    selectedTab.classList.add("active")
  }

  // Add active class to clicked nav item
  event.target.closest(".nav-item").classList.add("active")
}

// Apply for Job
function applyJob(company, position) {
  const notification = {
    type: "success",
    message: `You have successfully applied to ${company} for ${position} position!`,
  }

  const applications = JSON.parse(localStorage.getItem("applications")) || []
  applications.push({
    company: company,
    position: position,
    appliedOn: new Date().toISOString().split("T")[0],
    status: "Pending Review",
  })

  localStorage.setItem("applications", JSON.stringify(applications))
  showNotification(notification.message, "success")
}

// Show Notification
function showNotification(message, type = "info") {
  const notification = document.createElement("div")
  notification.className = `notification notification-${type}`
  notification.textContent = message
  document.body.appendChild(notification)

  setTimeout(() => {
    notification.classList.add("show")
  }, 100)

  setTimeout(() => {
    notification.classList.remove("show")
    setTimeout(() => notification.remove(), 300)
  }, 3000)
}

// Add notification styles
const style = document.createElement("style")
style.textContent = `
    .notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 5px;
        color: white;
        opacity: 0;
        transition: all 0.3s ease;
        z-index: 2000;
    }

    .notification.show {
        opacity: 1;
    }

    .notification-success {
        background-color: #22c55e;
    }

    .notification-error {
        background-color: #ef4444;
    }

    .notification-info {
        background-color: #3b82f6;
    }
`
document.head.appendChild(style)

// Menu Toggle
document.getElementById("menuToggle").addEventListener("click", () => {
  document.querySelector(".sidebar").style.left = "0"
})

document.getElementById("closeSidebar").addEventListener("click", () => {
  document.querySelector(".sidebar").style.left = "-250px"
})
