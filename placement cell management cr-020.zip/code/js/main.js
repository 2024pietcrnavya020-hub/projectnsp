// DOM Elements
const loginModal = document.getElementById("loginModal")
const loginForm = document.getElementById("loginForm")
const navMenu = document.getElementById("navMenu")
const hamburger = document.getElementById("hamburger")
const userRoleInput = document.getElementById("userRole")

// User Database (Mock - Replace with backend API)
const users = {
  student: {
    "student@piet.ac.in": { password: "student123", role: "student" },
  },
  admin: {
    "admin@piet.ac.in": { password: "admin123", role: "admin" },
  },
  company: {
    "company@piet.ac.in": { password: "company123", role: "company" },
  },
}

// Open Login Modal
function openLoginModal() {
  loginModal.classList.add("active")
}

// Close Login Modal
function closeLoginModal() {
  loginModal.classList.remove("active")
}

// Switch Login Tab
function switchTab(role) {
  document.querySelectorAll(".tab-btn").forEach((btn) => btn.classList.remove("active"))
  event.target.classList.add("active")
  userRoleInput.value = role
}

// Hamburger Menu Toggle
hamburger.addEventListener("click", () => {
  navMenu.classList.toggle("active")
})

// Close menu when link is clicked
document.querySelectorAll(".nav-link").forEach((link) => {
  link.addEventListener("click", () => {
    navMenu.classList.remove("active")
  })
})

// Smooth Scroll
function scrollToSection(sectionId) {
  const element = document.getElementById(sectionId)
  if (element) {
    element.scrollIntoView({ behavior: "smooth" })
    navMenu.classList.remove("active")
  }
}

// Handle Login Form Submission
loginForm.addEventListener("submit", (e) => {
  e.preventDefault()
  const email = document.getElementById("email").value
  const password = document.getElementById("password").value
  const role = userRoleInput.value

  // Validate user
  if (users[role] && users[role][email] && users[role][email].password === password) {
    // Store user info in localStorage
    localStorage.setItem(
      "currentUser",
      JSON.stringify({
        email: email,
        role: role,
        loginTime: new Date().toISOString(),
      }),
    )

    // Redirect to dashboard
    window.location.href = `dashboard-${role}.html`
  } else {
    showNotification("Invalid email or password!", "error")
  }
})

// Contact Form Submission
function submitContact(e) {
  e.preventDefault()
  showNotification("Thank you! We will contact you soon.", "success")
  e.target.reset()
}

// Notification System
function showNotification(message, type = "info") {
  const notification = document.createElement("div")
  notification.className = `notification notification-${type}`
  notification.textContent = message
  document.body.appendChild(notification)

  setTimeout(() => {
    notification.classList.add("show")
  }, 100)

  setTimeout(() => {
    notification.classList.remove("show")
    setTimeout(() => notification.remove(), 300)
  }, 3000)
}

// Add notification styles dynamically
const style = document.createElement("style")
style.textContent = `
    .notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 5px;
        color: white;
        opacity: 0;
        transition: all 0.3s ease;
        z-index: 2000;
    }

    .notification.show {
        opacity: 1;
        transform: translateX(0);
    }

    .notification-success {
        background-color: #22c55e;
    }

    .notification-error {
        background-color: #ef4444;
    }

    .notification-info {
        background-color: #3b82f6;
    }

    .notification-warning {
        background-color: #f59e0b;
    }
`
document.head.appendChild(style)

// Update nav active link on scroll
window.addEventListener("scroll", () => {
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
  })

  const sections = ["home", "about", "companies", "contact"]
  sections.forEach((sectionId) => {
    const section = document.getElementById(sectionId)
    if (section) {
      const rect = section.getBoundingClientRect()
      if (rect.top <= 200 && rect.bottom >= 200) {
        document.querySelector(`[href="#${sectionId}"]`)?.classList.add("active")
      }
    }
  })
})

// Close modal when clicking outside
window.addEventListener("click", (e) => {
  if (e.target === loginModal) {
    closeLoginModal()
  }
})
